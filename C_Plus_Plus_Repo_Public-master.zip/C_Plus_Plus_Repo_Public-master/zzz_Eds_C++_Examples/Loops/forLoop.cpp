//Hello World ForLoop example
/* By Ed */
//iostream used for inputting and outputting
#include <iostream>
using namespace std;

//Main is always the first to run
int main()
{
	// The For Loop tests the condition of the loop first, and then tests the body:
    for (int x = 0; x < 5; x++){
        cout << "Hello, world!!!" << x << endl;
    }    
	return 0;
}
