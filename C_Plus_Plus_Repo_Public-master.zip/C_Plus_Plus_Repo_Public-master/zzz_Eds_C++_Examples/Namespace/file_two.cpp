#include <iostream>

    // Define a namespace
        namespace two{ // the namespace name is "two"

        void display(){

            std::cout << "Display from file two! \n"; // I used "std::" instead of "using namespace std;" for cout

        }
}