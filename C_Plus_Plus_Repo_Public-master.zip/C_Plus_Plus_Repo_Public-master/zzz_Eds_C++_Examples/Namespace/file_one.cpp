#include <iostream>

    // Define a namespace
        namespace one{ // the namespace name is "one"

        void display(){
            
            std::cout << "Display from file one! \n"; // I used "std::" instead of "using namespace std;" for cout

        }
}
