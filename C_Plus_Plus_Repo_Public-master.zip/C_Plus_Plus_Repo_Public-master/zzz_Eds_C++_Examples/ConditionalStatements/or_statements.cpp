//The "Or" operator
/* By Ed */
//iostream used for inputting and outputting
#include <iostream>
using namespace std;

//Main is always the first to run
int main()
{
	int x = 4;
    int y = 10;
    
    if ((x == 5) || (y == 10)){

        cout << "Either x or y was a match!" << endl;
    }        
	return 0;
}
