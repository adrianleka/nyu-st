//If-else statement example
/* By Ed */
//iostream used for inputting and outputting
#include <iostream>
using namespace std;

//Main is always the first to run
int main()
{
	int x = 7;

    if (x == 6){

        // the double equal ""=="" is the operator for equality
        cout << "x is equal to 6" << endl;

    } else {

        cout << "x is equal to 7" << endl;

    }
        
	return 0;
}
