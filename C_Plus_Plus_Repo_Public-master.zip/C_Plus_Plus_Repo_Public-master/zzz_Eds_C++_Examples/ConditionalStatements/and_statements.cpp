//The "And" operators
/* By Ed */
//iostream used for inputting and outputting
#include <iostream>
using namespace std;

//Main is always the first to run
int main()
{
	int x = 5;
    int y = 5;
    
    if ((x > 0) && (y < 10)){

        cout << "x > 0 and y < 10" << endl;
    }        
	return 0;
}
