// Divison operator
/* By Ed */
//iostream used for inputting and outputting
#include <iostream>
using namespace std;

//Main is always the first to run
int main()
{
    int someVariable = 10;
    
    // Divide someVariable by 5 put the answer back into the variable using /=
    someVariable /= 5;

    // Display to the screen
    cout << someVariable << endl;
    // someVariable now equals 2

	return 0;
}