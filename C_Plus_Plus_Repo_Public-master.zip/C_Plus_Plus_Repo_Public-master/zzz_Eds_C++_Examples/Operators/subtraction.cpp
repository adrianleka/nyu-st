// Subtraction operator
/* By Ed */
//iostream used for inputting and outputting
#include <iostream>
using namespace std;

//Main is always the first to run
int main()
{
    int someVariable = 10;
    
    // Subtract 3 from someVariable and put the answer back into the variable using -=
    someVariable -= 3;

    // Display to the screen
    cout << someVariable << endl;
    // someVariable now equals 7

	return 0;
}