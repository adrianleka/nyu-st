//Hello World example
/* By Ed */
//iostream used for inputting and outputting
#include <iostream>
using namespace std;

//Main is always the first to run
int main()
{
	cout << "Hello, world!!!" << endl;
	return 0;
}
