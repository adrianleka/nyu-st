// ****************************************************
// Title of project goes here
// By Ed
// ****************************************************

#include <iostream>
using namespace std;

int main(){

    // Variable_Declarations

    // Statement 1
    // Statement 2
    // ...
    // Statement -- The last one

    return 0;
}