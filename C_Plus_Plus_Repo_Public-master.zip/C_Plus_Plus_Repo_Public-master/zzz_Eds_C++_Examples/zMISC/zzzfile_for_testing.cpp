//Hello World example
/* By Ed */
//iostream used for inputting and outputting
#include <iostream>
using namespace std;

//Main is always the first to run
int main()
{

	double y = 5.0/2;
	cout << y << endl;
	return 0;
}
